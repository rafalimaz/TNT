var jiraUser, jiraPassword, jiraRestApi, JiraSearchQuery;

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
        switch (request.directive) {
            case "options":
                jiraUser = request.jiraUser;
                jiraPassword = request.jiraPassword;
                jiraRestApi = request.jiraRestApi;
                jiraSearchQuery = request.jiraSearchQuery;
                featureCheckDevBugIssues(request.notifyNewOpenIssues);
                break;
            case "test":
                alert("test received on background");
                sendResponse({});
                break;
            default:
                alert("Unmatched request of '" + request + "' from script to background.js from " + sender);
        }
    }
);

$(function() {
    loadFeatures();
    console.log("background loaded");
});

function loadFeatures() {
    chrome.storage.sync.get({
        notifyNewOpenIssues : true,
        jiraUser: "",
        jiraPassword: "",
        jiraRestApi: "",
        jiraSearchQuery: ""
	}, function(items) {
        jiraUser = items.jiraUser;
        jiraPassword = items.jiraPassword;
        jiraRestApi = items.jiraRestApi;
        jiraSearchQuery = items.jiraSearchQuery;
        featureCheckDevBugIssues(items.notifyNewOpenIssues);
    });
}

function featureCheckDevBugIssues(enable) {
    if (enable) {
        setInterval(checkDevBugIssues, 20000);
    } else {
        chrome.browserAction.setBadgeText({text: "..." });
    }
}

function checkDevBugIssues() {
    $.ajax({
        type: 'GET',
        url: jiraRestApi + "/search?jql=" + encodeURIComponent(jiraSearchQuery),
        beforeSend: function (xhr) {
            xhr.setRequestHeader ("Authorization", "Basic " + btoa(jiraUser + ":" + jiraPassword));
        },
        success: function(data)
        {
            chrome.browserAction.setBadgeText({text: data.issues.length.toString() });
        },
        error: function(error) {
            alert("Error searching jira issues. Please fix Jira Search Query on options page!");
            chrome.browserAction.setBadgeText({text: "error" });
        }
    });
}